var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');


//se carga el modulo de sqlite3
var sqlite3 = require('sqlite3');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
const {process_params} = require("express/lib/router");

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

//se carga el modulo knex
//se inicializa knez con sqlite3

var db = require('knex')({
        client: 'sqlite3',
        connection: {
            filename: 'libros.sqlite'
        },
        useNullAsDefault: true
    }
);



//no se utilizan las rutas predefinidas
//app.use('/', indexRouter);
//app.use('/users', usersRouter);

//rutas del usuario


//rutas de libros
app.get('/api/libros', function(req, res){
    db.select('l.id',
        'l.titulo',
        'l.año_publicacion',
        'l.coleccion',
        'l.genero',
        'l.editorial',
        'l.autor',
        'l.ref',
        'l.portada')
        .from('libros as l')
        .then( function(data){
            result={};
            result.libros = data;
            res.json(result);
        });
});

//seleccion por id
/*app.get('/api/libros/:id', function(req, res){
    //seleccionar id, titulo, año de publicacion,coleccion, genero, editorial,autor, ref , portada from Libros
    //where id = parametro_id, //lo convertimos a entero
   let id = parseInt(req.params.id);

    db.select('l.id',
        'l.titulo',
        'l.año_publicacion',
        'l.coleccion',
        'l.genero',
        'l.editorial',
        'l.autor',
        'l.ref',
        'l.portada')

        .from('libros as l')
        .where('l.id',id)
        .then( function(data){
            res.json(data)
        });

});*/

//no funciona si le pasamos el param titulo :(

/*app.get('/api/libros/:titulo', function(req, res){
    //seleccionar id, titulo, año de publicacion,coleccion, genero, editorial,autor, ref , portada from Libros
    //where id = parametro_id, //lo convertimos a entero
    let titulo = req.params.titulo;

    db.select('l.id',
        'l.titulo',
        'l.año_publicacion',
        'l.coleccion',
        'l.genero',
        'l.editorial',
        'l.autor',
        'l.ref',
        'l.portada')

        .from('libros as l')
        .where('l.titulo',titulo)
        .then( function(data){
            res.json(data)
        });
});*/

//buscar un libro por id y por titulo, este codigo evita que interfieran entre ellos
app.get('/api/libros/:busqueda', function(req, res) {
    let busqueda = req.params.busqueda;
    if (isNaN(parseInt(busqueda))) {
        // Asume que la búsqueda es por título si no es un número
        db.select('l.id',
            'l.titulo',
            'l.año_publicacion',
            'l.coleccion',
            'l.genero',
            'l.editorial',
            'l.autor',
            'l.ref',
            'l.portada')
            .from('libros as l')
            .where('l.titulo', 'like', `%${busqueda}%`)
            .then(function(data) {
                res.json(data);
            })

    } else {
        // Buscar por ID
        let id = parseInt(busqueda);
        db.select('l.id',
            'l.titulo',
            'l.año_publicacion',
            'l.coleccion',
            'l.genero',
            'l.editorial',
            'l.autor',
            'l.ref',
            'l.portada')
            .from('libros as l')
            .where('l.id', id)
            .then(function(data) {
                res.json(data);
            })
    }
});

//metodo delete para eliminar elementos de la API por id
app.delete('/api/libros/:id', function(req, res) {
        // Buscar por ID
        let id = parseInt(req.params.id);
    db.delete()
        .from('libros')
        .where('id', id)
        .then(function(data) {
            res.json(data);
        })
        });

app.use(express.static('public'));


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
